require 'test/unit'
class TestDupa < Test::Unit::TestCase
    
    def test_jakaka 
        
    end
end

